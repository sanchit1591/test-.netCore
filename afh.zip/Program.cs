﻿using System;
using AutoUpdaterDotNET;

namespace autoFinal
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoUpdater.Synchronous = true;
            AutoUpdater.Start("https://raw.githubusercontent.com/sanchit1591/test-.netCore/main/update.xml");
            Console.WriteLine("Hello World!");
        }
    }
}
