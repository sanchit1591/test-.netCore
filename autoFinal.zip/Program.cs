﻿using System;
using System.IO;
using System.Windows;
using AutoUpdaterDotNET;

namespace autoFinal
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoUpdater.Synchronous = true;
            //AutoUpdater.Mandatory = true;
            //AutoUpdater.UpdateMode = Mode.
            AutoUpdater.Start("https://raw.githubusercontent.com/sanchit1591/test-.netCore/main/update.xml");

            Console.WriteLine("hello World!");
        }
    }
}
