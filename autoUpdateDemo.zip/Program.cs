﻿using System;
using System.Diagnostics;
using AutoUpdaterDotNET;

namespace autoUpdateDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoUpdater.Synchronous = true;
            AutoUpdater.Start("https://raw.githubusercontent.com/sanchit1591/test-.netCore/main/update.xml");
            //var versionInfo = FileVersionInfo.GetVersionInfo(@"C:\Users\sanchita\source\repos\autoUpdateDemo\bin\Debug\netcoreapp3.1\autoUpdateDemo.exe");
            //string version = versionInfo.FileVersion;
            //Console.WriteLine(version);
            Console.WriteLine("version testing ");
        }
    }
}
